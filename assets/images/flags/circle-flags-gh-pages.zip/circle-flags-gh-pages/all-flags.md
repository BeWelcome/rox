<link rel="stylesheet" type="text/css" href="gallery.css" />

<h1>Gallery</h1>

<div class="container">
  <div><img src="flags/ad.svg" width="100"/><p>Andorra (<code>AD</code>)</p></div>
  <div><img src="flags/ae.svg" width="100"/><p>United Arab Emirates (<code>AE</code>)</p></div>
  <div><img src="flags/af.svg" width="100"/><p>Afghanistan (<code>AF</code>)</p></div>
  <div><img src="flags/ag.svg" width="100"/><p>Antigua and Barbuda (<code>AG</code>)</p></div>
  <div><img src="flags/ai.svg" width="100"/><p>Anguilla (<code>AI</code>)</p></div>
  <div><img src="flags/al.svg" width="100"/><p>Albania (<code>AL</code>)</p></div>
  <div><img src="flags/am.svg" width="100"/><p>Armenia (<code>AM</code>)</p></div>
  <div><img src="flags/ao.svg" width="100"/><p>Angola (<code>AO</code>)</p></div>
  <div><img src="flags/xx.svg" width="100"/><p>Antarctica (<code>AQ</code>)</p></div>
  <div><img src="flags/ar.svg" width="100"/><p>Argentina (<code>AR</code>)</p></div>
  <div><img src="flags/as.svg" width="100"/><p>American Samoa (<code>AS</code>)</p></div>
  <div><img src="flags/at.svg" width="100"/><p>Austria (<code>AT</code>)</p></div>
  <div><img src="flags/au.svg" width="100"/><p>Australia (<code>AU</code>)</p></div>
  <div><img src="flags/aw.svg" width="100"/><p>Aruba (<code>AW</code>)</p></div>
  <div><img src="flags/ax.svg" width="100"/><p>Åland Islands (<code>AX</code>)</p></div>
  <div><img src="flags/az.svg" width="100"/><p>Azerbaijan (<code>AZ</code>)</p></div>
  <div><img src="flags/ba.svg" width="100"/><p>Bosnia and Herzegovina (<code>BA</code>)</p></div>
  <div><img src="flags/bb.svg" width="100"/><p>Barbados (<code>BB</code>)</p></div>
  <div><img src="flags/bd.svg" width="100"/><p>Bangladesh (<code>BD</code>)</p></div>
  <div><img src="flags/be.svg" width="100"/><p>Belgium (<code>BE</code>)</p></div>
  <div><img src="flags/bf.svg" width="100"/><p>Burkina Faso (<code>BF</code>)</p></div>
  <div><img src="flags/bg.svg" width="100"/><p>Bulgaria (<code>BG</code>)</p></div>
  <div><img src="flags/bh.svg" width="100"/><p>Bahrain (<code>BH</code>)</p></div>
  <div><img src="flags/bi.svg" width="100"/><p>Burundi (<code>BI</code>)</p></div>
  <div><img src="flags/bj.svg" width="100"/><p>Benin (<code>BJ</code>)</p></div>
  <div><img src="flags/bl.svg" width="100"/><p>Saint Barthélemy (<code>BL</code>)</p></div>
  <div><img src="flags/bm.svg" width="100"/><p>Bermuda (<code>BM</code>)</p></div>
  <div><img src="flags/bn.svg" width="100"/><p>Brunei (<code>BN</code>)</p></div>
  <div><img src="flags/bo.svg" width="100"/><p>Bolivia (<code>BO</code>)</p></div>
  <div><img src="flags/bq-bo.svg" width="100"/><p>Bonaire (<code>BQ-BO</code>)</p></div>
  <div><img src="flags/bq-sa.svg" width="100"/><p>Saba (<code>BQ-SA</code>)</p></div>
  <div><img src="flags/bq-se.svg" width="100"/><p>Sint Eustatius (<code>BQ-SE</code>)</p></div>
  <div><img src="flags/br.svg" width="100"/><p>Brazil (<code>BR</code>)</p></div>
  <div><img src="flags/bs.svg" width="100"/><p>Bahamas (<code>BS</code>)</p></div>
  <div><img src="flags/bt.svg" width="100"/><p>Bhutan (<code>BT</code>)</p></div>
  <div><img src="flags/xx.svg" width="100"/><p>Bouvet Island (<code>BV</code>)</p></div>
  <div><img src="flags/bw.svg" width="100"/><p>Botswana (<code>BW</code>)</p></div>
  <div><img src="flags/by.svg" width="100"/><p>Belarus (<code>BY</code>)</p></div>
  <div><img src="flags/bz.svg" width="100"/><p>Belize (<code>BZ</code>)</p></div>
  <div><img src="flags/ca-bc.svg" width="100"/><p>British Columbia</p></div>
  <div><img src="flags/ca.svg" width="100"/><p>Canada (<code>CA</code>)</p></div>
  <div><img src="flags/cc.svg" width="100"/><p>Cocos (Keeling) Islands (<code>CC</code>)</p></div>
  <div><img src="flags/cd.svg" width="100"/><p>Congo, Democratic Republic of the (<code>CD</code>)</p></div>
  <div><img src="flags/cf.svg" width="100"/><p>Central African Republic (<code>CF</code>)</p></div>
  <div><img src="flags/cg.svg" width="100"/><p>Congo (<code>CG</code>)</p></div>
  <div><img src="flags/ch.svg" width="100"/><p>Switzerland (<code>CH</code>)</p></div>
  <div><img src="flags/ci.svg" width="100"/><p>Ivory Coast (<code>CI</code>)</p></div>
  <div><img src="flags/ck.svg" width="100"/><p>Cook Islands (<code>CK</code>)</p></div>
  <div><img src="flags/cl.svg" width="100"/><p>Chile (<code>CL</code>)</p></div>
  <div><img src="flags/cm.svg" width="100"/><p>Cameroon (<code>CM</code>)</p></div>
  <div><img src="flags/cn.svg" width="100"/><p>China (<code>CN</code>)</p></div>
  <div><img src="flags/co.svg" width="100"/><p>Colombia (<code>CO</code>)</p></div>
  <div><img src="flags/cr.svg" width="100"/><p>Costa Rica (<code>CR</code>)</p></div>
  <div><img src="flags/cu.svg" width="100"/><p>Cuba (<code>CU</code>)</p></div>
  <div><img src="flags/cv.svg" width="100"/><p>Cabo Verde (<code>CV</code>)</p></div>
  <div><img src="flags/cw.svg" width="100"/><p>Curaçao (<code>CW</code>)</p></div>
  <div><img src="flags/cx.svg" width="100"/><p>Christmas Island (<code>CX</code>)</p></div>
  <div><img src="flags/cy.svg" width="100"/><p>Cyprus (<code>CY</code>)</p></div>
  <div><img src="flags/cz.svg" width="100"/><p>Czechia (<code>CZ</code>)</p></div>
  <div><img src="flags/de.svg" width="100"/><p>Germany (<code>DE</code>)</p></div>
  <div><img src="flags/dj.svg" width="100"/><p>Djibouti (<code>DJ</code>)</p></div>
  <div><img src="flags/dk.svg" width="100"/><p>Denmark (<code>DK</code>)</p></div>
  <div><img src="flags/dm.svg" width="100"/><p>Dominica (<code>DM</code>)</p></div>
  <div><img src="flags/do.svg" width="100"/><p>Dominican Republic (<code>DO</code>)</p></div>
  <div><img src="flags/dz.svg" width="100"/><p>Algeria (<code>DZ</code>)</p></div>
  <div><img src="flags/easter_island.svg" width="100"/><p>Easter Island</p></div>
  <div><img src="flags/ec-w.svg" width="100"/><p>Galápagos</p></div>
  <div><img src="flags/ec.svg" width="100"/><p>Ecuador (<code>EC</code>)</p></div>
  <div><img src="flags/ee.svg" width="100"/><p>Estonia (<code>EE</code>)</p></div>
  <div><img src="flags/eg.svg" width="100"/><p>Egypt (<code>EG</code>)</p></div>
  <div><img src="flags/eh.svg" width="100"/><p>Western Sahara (<code>EH</code>)</p></div>
  <div><img src="flags/er.svg" width="100"/><p>Eritrea (<code>ER</code>)</p></div>
  <div><img src="flags/es-ce.svg" width="100"/><p>Ceuta</p></div>
  <div><img src="flags/es-cn.svg" width="100"/><p>Canary Islands</p></div>
  <div><img src="flags/es-ga.svg" width="100"/><p>Galicia</p></div>
  <div><img src="flags/es-ib.svg" width="100"/><p>Balearic Islands</p></div>
  <div><img src="flags/es-ml.svg" width="100"/><p>Melilla</p></div>
  <div><img src="flags/es-pv.svg" width="100"/><p>Basque Country</p></div>
  <div><img src="flags/es.svg" width="100"/><p>Spain (<code>ES</code>)</p></div>
  <div><img src="flags/esperanto.svg" width="100"/><p>Esperanto</p></div>
  <div><img src="flags/et.svg" width="100"/><p>Ethiopia (<code>ET</code>)</p></div>
  <div><img src="flags/european_union.svg" width="100"/><p>European Union</p></div>
  <div><img src="flags/fi.svg" width="100"/><p>Finland (<code>FI</code>)</p></div>
  <div><img src="flags/fj.svg" width="100"/><p>Fiji (<code>FJ</code>)</p></div>
  <div><img src="flags/fk.svg" width="100"/><p>Falkland Islands (Malvinas) (<code>FK</code>)</p></div>
  <div><img src="flags/fm.svg" width="100"/><p>Micronesia (<code>FM</code>)</p></div>
  <div><img src="flags/fo.svg" width="100"/><p>Faroe Islands (<code>FO</code>)</p></div>
  <div><img src="flags/fr-h.svg" width="100"/><p>Corsica</p></div>
  <div><img src="flags/fr.svg" width="100"/><p>France (<code>FR</code>)</p></div>
  <div><img src="flags/ga.svg" width="100"/><p>Gabon (<code>GA</code>)</p></div>
  <div><img src="flags/gb-eng.svg" width="100"/><p>England</p></div>
  <div><img src="flags/gb-ork.svg" width="100"/><p>Orkney</p></div>
  <div><img src="flags/gb-sct.svg" width="100"/><p>Scotland</p></div>
  <div><img src="flags/gb-wls.svg" width="100"/><p>Wales</p></div>
  <div><img src="flags/gb.svg" width="100"/><p>United Kingdom (<code>GB</code>)</p></div>
  <div><img src="flags/gd.svg" width="100"/><p>Grenada (<code>GD</code>)</p></div>
  <div><img src="flags/ge.svg" width="100"/><p>Georgia (<code>GE</code>)</p></div>
  <div><img src="flags/gf.svg" width="100"/><p>French Guiana (<code>GF</code>)</p></div>
  <div><img src="flags/gg.svg" width="100"/><p>Guernsey (<code>GG</code>)</p></div>
  <div><img src="flags/gh.svg" width="100"/><p>Ghana (<code>GH</code>)</p></div>
  <div><img src="flags/gi.svg" width="100"/><p>Gibraltar (<code>GI</code>)</p></div>
  <div><img src="flags/gl.svg" width="100"/><p>Greenland (<code>GL</code>)</p></div>
  <div><img src="flags/gm.svg" width="100"/><p>Gambia (<code>GM</code>)</p></div>
  <div><img src="flags/gn.svg" width="100"/><p>Guinea (<code>GN</code>)</p></div>
  <div><img src="flags/xx.svg" width="100"/><p>Guadeloupe (<code>GP</code>)</p></div>
  <div><img src="flags/gq.svg" width="100"/><p>Equatorial Guinea (<code>GQ</code>)</p></div>
  <div><img src="flags/gr.svg" width="100"/><p>Greece (<code>GR</code>)</p></div>
  <div><img src="flags/xx.svg" width="100"/><p>South Georgia and the South Sandwich Islands (<code>GS</code>)</p></div>
  <div><img src="flags/gt.svg" width="100"/><p>Guatemala (<code>GT</code>)</p></div>
  <div><img src="flags/gu.svg" width="100"/><p>Guam (<code>GU</code>)</p></div>
  <div><img src="flags/gw.svg" width="100"/><p>Guinea-Bissau (<code>GW</code>)</p></div>
  <div><img src="flags/gy.svg" width="100"/><p>Guyana (<code>GY</code>)</p></div>
  <div><img src="flags/hausa.svg" width="100"/><p>Hausa</p></div>
  <div><img src="flags/hk.svg" width="100"/><p>Hong Kong (<code>HK</code>)</p></div>
  <div><img src="flags/hmong.svg" width="100"/><p>Hmong</p></div>
  <div><img src="flags/xx.svg" width="100"/><p>Heard Island and McDonald Islands (<code>HM</code>)</p></div>
  <div><img src="flags/hn.svg" width="100"/><p>Honduras (<code>HN</code>)</p></div>
  <div><img src="flags/hr.svg" width="100"/><p>Croatia (<code>HR</code>)</p></div>
  <div><img src="flags/ht.svg" width="100"/><p>Haiti (<code>HT</code>)</p></div>
  <div><img src="flags/hu.svg" width="100"/><p>Hungary (<code>HU</code>)</p></div>
  <div><img src="flags/id.svg" width="100"/><p>Indonesia (<code>ID</code>)</p></div>
  <div><img src="flags/ie.svg" width="100"/><p>Ireland (<code>IE</code>)</p></div>
  <div><img src="flags/il.svg" width="100"/><p>Israel (<code>IL</code>)</p></div>
  <div><img src="flags/im.svg" width="100"/><p>Isle of Man (<code>IM</code>)</p></div>
  <div><img src="flags/in.svg" width="100"/><p>India (<code>IN</code>)</p></div>
  <div><img src="flags/io.svg" width="100"/><p>British Indian Ocean Territory (<code>IO</code>)</p></div>
  <div><img src="flags/iq.svg" width="100"/><p>Iraq (<code>IQ</code>)</p></div>
  <div><img src="flags/ir.svg" width="100"/><p>Iran (<code>IR</code>)</p></div>
  <div><img src="flags/is.svg" width="100"/><p>Iceland (<code>IS</code>)</p></div>
  <div><img src="flags/it-82.svg" width="100"/><p>Sicily</p></div>
  <div><img src="flags/it-88.svg" width="100"/><p>Sardinia</p></div>
  <div><img src="flags/it.svg" width="100"/><p>Italy (<code>IT</code>)</p></div>
  <div><img src="flags/je.svg" width="100"/><p>Jersey (<code>JE</code>)</p></div>
  <div><img src="flags/jm.svg" width="100"/><p>Jamaica (<code>JM</code>)</p></div>
  <div><img src="flags/jo.svg" width="100"/><p>Jordan (<code>JO</code>)</p></div>
  <div><img src="flags/jp.svg" width="100"/><p>Japan (<code>JP</code>)</p></div>
  <div><img src="flags/kannada.svg" width="100"/><p>Kannada</p></div>
  <div><img src="flags/ke.svg" width="100"/><p>Kenya (<code>KE</code>)</p></div>
  <div><img src="flags/kg.svg" width="100"/><p>Kyrgyzstan (<code>KG</code>)</p></div>
  <div><img src="flags/kh.svg" width="100"/><p>Cambodia (<code>KH</code>)</p></div>
  <div><img src="flags/ki.svg" width="100"/><p>Kiribati (<code>KI</code>)</p></div>
  <div><img src="flags/km.svg" width="100"/><p>Comoros (<code>KM</code>)</p></div>
  <div><img src="flags/kn.svg" width="100"/><p>Saint Kitts and Nevis (<code>KN</code>)</p></div>
  <div><img src="flags/kp.svg" width="100"/><p>North Korea (<code>KP</code>)</p></div>
  <div><img src="flags/kr.svg" width="100"/><p>South Korea (<code>KR</code>)</p></div>
  <div><img src="flags/kurdistan.svg" width="100"/><p>Kurdistan</p></div>
  <div><img src="flags/kw.svg" width="100"/><p>Kuwait (<code>KW</code>)</p></div>
  <div><img src="flags/ky.svg" width="100"/><p>Cayman Islands (<code>KY</code>)</p></div>
  <div><img src="flags/kz.svg" width="100"/><p>Kazakhstan (<code>KZ</code>)</p></div>
  <div><img src="flags/la.svg" width="100"/><p>Laos (<code>LA</code>)</p></div>
  <div><img src="flags/lb.svg" width="100"/><p>Lebanon (<code>LB</code>)</p></div>
  <div><img src="flags/lc.svg" width="100"/><p>Saint Lucia (<code>LC</code>)</p></div>
  <div><img src="flags/li.svg" width="100"/><p>Liechtenstein (<code>LI</code>)</p></div>
  <div><img src="flags/lk.svg" width="100"/><p>Sri Lanka (<code>LK</code>)</p></div>
  <div><img src="flags/lr.svg" width="100"/><p>Liberia (<code>LR</code>)</p></div>
  <div><img src="flags/ls.svg" width="100"/><p>Lesotho (<code>LS</code>)</p></div>
  <div><img src="flags/lt.svg" width="100"/><p>Lithuania (<code>LT</code>)</p></div>
  <div><img src="flags/lu.svg" width="100"/><p>Luxembourg (<code>LU</code>)</p></div>
  <div><img src="flags/lv.svg" width="100"/><p>Latvia (<code>LV</code>)</p></div>
  <div><img src="flags/ly.svg" width="100"/><p>Libya (<code>LY</code>)</p></div>
  <div><img src="flags/ma.svg" width="100"/><p>Morocco (<code>MA</code>)</p></div>
  <div><img src="flags/malayali.svg" width="100"/><p>Malayali</p></div>
  <div><img src="flags/maori.svg" width="100"/><p>Maori</p></div>
  <div><img src="flags/mc.svg" width="100"/><p>Monaco (<code>MC</code>)</p></div>
  <div><img src="flags/md.svg" width="100"/><p>Moldova (<code>MD</code>)</p></div>
  <div><img src="flags/me.svg" width="100"/><p>Montenegro (<code>ME</code>)</p></div>
  <div><img src="flags/xx.svg" width="100"/><p>Saint-Martin (<code>MF</code>)</p></div>
  <div><img src="flags/mg.svg" width="100"/><p>Madagascar (<code>MG</code>)</p></div>
  <div><img src="flags/mh.svg" width="100"/><p>Marshall Islands (<code>MH</code>)</p></div>
  <div><img src="flags/mk.svg" width="100"/><p>North Macedonia (<code>MK</code>)</p></div>
  <div><img src="flags/ml.svg" width="100"/><p>Mali (<code>ML</code>)</p></div>
  <div><img src="flags/mm.svg" width="100"/><p>Myanmar (<code>MM</code>)</p></div>
  <div><img src="flags/mn.svg" width="100"/><p>Mongolia (<code>MN</code>)</p></div>
  <div><img src="flags/mo.svg" width="100"/><p>Macao (<code>MO</code>)</p></div>
  <div><img src="flags/mp.svg" width="100"/><p>Northern Mariana Islands (<code>MP</code>)</p></div>
  <div><img src="flags/mq.svg" width="100"/><p>Martinique (<code>MQ</code>)</p></div>
  <div><img src="flags/mr.svg" width="100"/><p>Mauritania (<code>MR</code>)</p></div>
  <div><img src="flags/ms.svg" width="100"/><p>Montserrat (<code>MS</code>)</p></div>
  <div><img src="flags/mt.svg" width="100"/><p>Malta (<code>MT</code>)</p></div>
  <div><img src="flags/mu.svg" width="100"/><p>Mauritius (<code>MU</code>)</p></div>
  <div><img src="flags/mv.svg" width="100"/><p>Maldives (<code>MV</code>)</p></div>
  <div><img src="flags/mw.svg" width="100"/><p>Malawi (<code>MW</code>)</p></div>
  <div><img src="flags/mx.svg" width="100"/><p>Mexico (<code>MX</code>)</p></div>
  <div><img src="flags/my.svg" width="100"/><p>Malaysia (<code>MY</code>)</p></div>
  <div><img src="flags/mz.svg" width="100"/><p>Mozambique (<code>MZ</code>)</p></div>
  <div><img src="flags/na.svg" width="100"/><p>Namibia (<code>NA</code>)</p></div>
  <div><img src="flags/xx.svg" width="100"/><p>New Caledonia (<code>NC</code>)</p></div>
  <div><img src="flags/nato.svg" width="100"/><p>NATO</p></div>
  <div><img src="flags/ne.svg" width="100"/><p>Niger (<code>NE</code>)</p></div>
  <div><img src="flags/nf.svg" width="100"/><p>Norfolk Island (<code>NF</code>)</p></div>
  <div><img src="flags/ng.svg" width="100"/><p>Nigeria (<code>NG</code>)</p></div>
  <div><img src="flags/ni.svg" width="100"/><p>Nicaragua (<code>NI</code>)</p></div>
  <div><img src="flags/nl.svg" width="100"/><p>Netherlands (<code>NL</code>)</p></div>
  <div><img src="flags/no.svg" width="100"/><p>Norway (<code>NO</code>)</p></div>
  <div><img src="flags/northern_cyprus.svg" width="100"/><p>Northern Cyprus</p></div>
  <div><img src="flags/np.svg" width="100"/><p>Nepal (<code>NP</code>)</p></div>
  <div><img src="flags/nr.svg" width="100"/><p>Nauru (<code>NR</code>)</p></div>
  <div><img src="flags/nu.svg" width="100"/><p>Niue (<code>NU</code>)</p></div>
  <div><img src="flags/nz.svg" width="100"/><p>New Zealand (<code>NZ</code>)</p></div>
  <div><img src="flags/om.svg" width="100"/><p>Oman (<code>OM</code>)</p></div>
  <div><img src="flags/pa.svg" width="100"/><p>Panama (<code>PA</code>)</p></div>
  <div><img src="flags/pe.svg" width="100"/><p>Peru (<code>PE</code>)</p></div>
  <div><img src="flags/pf.svg" width="100"/><p>French Polynesia (<code>PF</code>)</p></div>
  <div><img src="flags/pg.svg" width="100"/><p>Papua New Guinea (<code>PG</code>)</p></div>
  <div><img src="flags/ph.svg" width="100"/><p>Philippines (<code>PH</code>)</p></div>
  <div><img src="flags/pk.svg" width="100"/><p>Pakistan (<code>PK</code>)</p></div>
  <div><img src="flags/pl.svg" width="100"/><p>Poland (<code>PL</code>)</p></div>
  <div><img src="flags/xx.svg" width="100"/><p>Saint Pierre and Miquelon (<code>PM</code>)</p></div>
  <div><img src="flags/pn.svg" width="100"/><p>Pitcairn Islands (<code>PN</code>)</p></div>
  <div><img src="flags/pr.svg" width="100"/><p>Puerto Rico (<code>PR</code>)</p></div>
  <div><img src="flags/ps.svg" width="100"/><p>Palestine (<code>PS</code>)</p></div>
  <div><img src="flags/pt-20.svg" width="100"/><p>Azores</p></div>
  <div><img src="flags/pt-30.svg" width="100"/><p>Madeira</p></div>
  <div><img src="flags/pt.svg" width="100"/><p>Portugal (<code>PT</code>)</p></div>
  <div><img src="flags/pw.svg" width="100"/><p>Palau (<code>PW</code>)</p></div>
  <div><img src="flags/py.svg" width="100"/><p>Paraguay (<code>PY</code>)</p></div>
  <div><img src="flags/qa.svg" width="100"/><p>Qatar (<code>QA</code>)</p></div>
  <div><img src="flags/xx.svg" width="100"/><p>Réunion (<code>RE</code>)</p></div>
  <div><img src="flags/ro.svg" width="100"/><p>Romania (<code>RO</code>)</p></div>
  <div><img src="flags/rs.svg" width="100"/><p>Serbia (<code>RS</code>)</p></div>
  <div><img src="flags/ru.svg" width="100"/><p>Russia (<code>RU</code>)</p></div>
  <div><img src="flags/rw.svg" width="100"/><p>Rwanda (<code>RW</code>)</p></div>
  <div><img src="flags/sa.svg" width="100"/><p>Saudi Arabia (<code>SA</code>)</p></div>
  <div><img src="flags/sb.svg" width="100"/><p>Solomon Islands (<code>SB</code>)</p></div>
  <div><img src="flags/sc.svg" width="100"/><p>Seychelles (<code>SC</code>)</p></div>
  <div><img src="flags/sd.svg" width="100"/><p>Sudan (<code>SD</code>)</p></div>
  <div><img src="flags/se.svg" width="100"/><p>Sweden (<code>SE</code>)</p></div>
  <div><img src="flags/sg.svg" width="100"/><p>Singapore (<code>SG</code>)</p></div>
  <div><img src="flags/xx.svg" width="100"/><p>Saint Helena (<code>SH-HL</code>)</p></div>
  <div><img src="flags/xx.svg" width="100"/><p>Ascension Island (<code>SH-AC</code>)</p></div>
  <div><img src="flags/xx.svg" width="100"/><p>Tristan da Cunha (<code>SH-TA</code>)</p></div>
  <div><img src="flags/si.svg" width="100"/><p>Slovenia (<code>SI</code>)</p></div>
  <div><img src="flags/sindh.svg" width="100"/><p>Svalbard and Jan Mayen (<code>SJ</code>)</p></div>
  <div><img src="flags/sk.svg" width="100"/><p>Slovakia (<code>SK</code>)</p></div>
  <div><img src="flags/sl.svg" width="100"/><p>Sierra Leone (<code>SL</code>)</p></div>
  <div><img src="flags/sm.svg" width="100"/><p>San Marino (<code>SM</code>)</p></div>
  <div><img src="flags/sn.svg" width="100"/><p>Senegal (<code>SN</code>)</p></div>
  <div><img src="flags/so.svg" width="100"/><p>Somalia (<code>SO</code>)</p></div>
  <div><img src="flags/somaliland.svg" width="100"/><p>Somaliland</p></div>
  <div><img src="flags/south_ossetia.svg" width="100"/><p>South Ossetia</p></div>
  <div><img src="flags/sr.svg" width="100"/><p>Suriname (<code>SR</code>)</p></div>
  <div><img src="flags/ss.svg" width="100"/><p>South Sudan (<code>SS</code>)</p></div>
  <div><img src="flags/st.svg" width="100"/><p>São Tomé and Príncipe (<code>ST</code>)</p></div>
  <div><img src="flags/sv.svg" width="100"/><p>El Salvador (<code>SV</code>)</p></div>
  <div><img src="flags/sx.svg" width="100"/><p>Sint Maarten (<code>SX</code>)</p></div>
  <div><img src="flags/sy.svg" width="100"/><p>Syria (<code>SY</code>)</p></div>
  <div><img src="flags/sz.svg" width="100"/><p>Eswatini (<code>SZ</code>)</p></div>
  <div><img src="flags/tc.svg" width="100"/><p>Turks and Caicos Islands (<code>TC</code>)</p></div>
  <div><img src="flags/td.svg" width="100"/><p>Chad (<code>TD</code>)</p></div>
  <div><img src="flags/xx.svg" width="100"/><p>French Southern Territories (<code>TF</code>)</p></div>
  <div><img src="flags/tg.svg" width="100"/><p>Togo (<code>TG</code>)</p></div>
  <div><img src="flags/th.svg" width="100"/><p>Thailand (<code>TH</code>)</p></div>
  <div><img src="flags/tibet.svg" width="100"/><p>Tibet</p></div>
  <div><img src="flags/tj.svg" width="100"/><p>Tajikistan (<code>TJ</code>)</p></div>
  <div><img src="flags/tk.svg" width="100"/><p>Tokelau (<code>TK</code>)</p></div>
  <div><img src="flags/tl.svg" width="100"/><p>Timor-Leste (<code>TL</code>)</p></div>
  <div><img src="flags/tm.svg" width="100"/><p>Turkmenistan (<code>TM</code>)</p></div>
  <div><img src="flags/tn.svg" width="100"/><p>Tunisia (<code>TN</code>)</p></div>
  <div><img src="flags/to.svg" width="100"/><p>Tonga (<code>TO</code>)</p></div>
  <div><img src="flags/tr.svg" width="100"/><p>Turkey (<code>TR</code>)</p></div>
  <div><img src="flags/transnistria.svg" width="100"/><p>Transnistria</p></div>
  <div><img src="flags/tt.svg" width="100"/><p>Trinidad and Tobago (<code>TT</code>)</p></div>
  <div><img src="flags/tv.svg" width="100"/><p>Tuvalu (<code>TV</code>)</p></div>
  <div><img src="flags/tw.svg" width="100"/><p>Taiwan (<code>TW</code>)</p></div>
  <div><img src="flags/tz.svg" width="100"/><p>Tanzania (<code>TZ</code>)</p></div>
  <div><img src="flags/ua.svg" width="100"/><p>Ukraine (<code>UA</code>)</p></div>
  <div><img src="flags/ug.svg" width="100"/><p>Uganda (<code>UG</code>)</p></div>
  <div><img src="flags/united_nations.svg" width="100"/><p>United Nations</p></div>
  <div><img src="flags/xx.svg" width="100"/><p>U.S. Minor Outlying Islands (<code>UM</code>)</p></div>
  <div><img src="flags/us-hi.svg" width="100"/><p>Hawaii</p></div>
  <div><img src="flags/us.svg" width="100"/><p>United States of America (<code>US</code>)</p></div>
  <div><img src="flags/uy.svg" width="100"/><p>Uruguay (<code>UY</code>)</p></div>
  <div><img src="flags/uz.svg" width="100"/><p>Uzbekistan (<code>UZ</code>)</p></div>
  <div><img src="flags/va.svg" width="100"/><p>Holy See (Vatican) (<code>VA</code>)</p></div>
  <div><img src="flags/vc.svg" width="100"/><p>Saint Vincent and the Grenadines (<code>VC</code>)</p></div>
  <div><img src="flags/ve.svg" width="100"/><p>Venezuela (<code>VE</code>)</p></div>
  <div><img src="flags/vg.svg" width="100"/><p>Virgin Islands (British) (<code>VG</code>)</p></div>
  <div><img src="flags/vi.svg" width="100"/><p>Virgin Islands (U.S.) (<code>VI</code>)</p></div>
  <div><img src="flags/vn.svg" width="100"/><p>Vietnam (<code>VN</code>)</p></div>
  <div><img src="flags/vu.svg" width="100"/><p>Vanuatu (<code>VU</code>)</p></div>
  <div><img src="flags/xx.svg" width="100"/><p>Wallis and Futuna (<code>WF</code>)</p></div>
  <div><img src="flags/ws.svg" width="100"/><p>Samoa (<code>WS</code>)</p></div>
  <div><img src="flags/xk.svg" width="100"/><p>Kosovo (<code>XK</code>)</p></div>
  <div><img src="flags/xx.svg" width="100"/><p>&lt;Placeholder&gt;</p></div>
  <div><img src="flags/ye.svg" width="100"/><p>Yemen (<code>YE</code>)</p></div>
  <div><img src="flags/xx.svg" width="100"/><p>Mayotte (<code>YT</code>)</p></div>
  <div><img src="flags/yiddish.svg" width="100"/><p>Yiddish</p></div>
  <div><img src="flags/za.svg" width="100"/><p>South Africa (<code>ZA</code>)</p></div>
  <div><img src="flags/zm.svg" width="100"/><p>Zambia (<code>ZM</code>)</p></div>
  <div><img src="flags/zw.svg" width="100"/><p>Zimbabwe (<code>ZW</code>)</p></div>
</div>
